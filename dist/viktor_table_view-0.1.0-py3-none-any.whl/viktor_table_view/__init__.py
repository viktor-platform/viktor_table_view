"""Initializes viktor_table_view package by importing the relevant handles"""
from viktor_table_view.table_view import TableResult
from viktor_table_view.table_view import TableView
